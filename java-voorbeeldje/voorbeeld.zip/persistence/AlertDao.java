package ipass.server.persistence;

import ipass.server.domain.AlertEntity;

public interface AlertDao extends GenericDao<AlertEntity>{
	
}
