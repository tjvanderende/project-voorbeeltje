package ipass.server.persistence;

import ipass.server.domain.AlarmEntity;

public interface AlarmDao extends GenericDao<AlarmEntity> {

}
